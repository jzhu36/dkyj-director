# DKYJ runtime entry. License and corresponding source: SOURCE.md.
from pathlib import Path as _P
import os as _os, json as _json, sys as _sys, marshal as _marshal
from importlib.util import MAGIC_NUMBER as _magic
_here = _P(__file__).resolve()
_config = _here.with_name('dkyj_workspace.json')
_root = _P(_os.environ.get('DKYJ_HOME') or (_json.loads(_config.read_text(encoding='utf-8'))['root'] if _config.exists() else _here.parents[1]))
_version = '%s.%s' % _sys.version_info[:2]
_blob = _root / '_runtime' / _version / 'licensing/entitlement.pyc'
if not _blob.is_file():
    raise RuntimeError('DKYJ supports CPython 3.10–3.14. Please install Python 3.11–3.14 and Blender 5.2, then run setup again.')
_data = _blob.read_bytes()
if _data[:4] != _magic:
    raise RuntimeError('DKYJ runtime version mismatch; reinstall the complete client.')
exec(_marshal.loads(_data[16:]), globals())
