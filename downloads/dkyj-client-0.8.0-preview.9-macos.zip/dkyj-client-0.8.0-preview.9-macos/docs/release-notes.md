# DKYJ Director 0.8.0-preview.9

- 统一 Mac / Windows 客户端目录与运行模块加载方式，支持 CPython 3.10–3.14 运行环境（安装推荐 3.11–3.14）。
- 保留镜头／空间／合并导出、手柄速度调节、简化白模、单描述建模与爱发电购买入口。
- 旧版分发入口统一指向当前客户端。升级前保存工程并退出 Blender，迁移 projects/ 与 takes/，不迁移 .venv/ 或 runtime/。
- 本版仍需 Blender 与 Python，不是包含这些依赖的一体离线包。
